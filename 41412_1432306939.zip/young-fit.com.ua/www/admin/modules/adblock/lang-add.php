<?php
  /**
   * Language Data Add
   *
   * @package CMS Pro
   * @author wojoscripts.com
   * @copyright 2014
   * @version $Id: lang-add.php, v4.00 2014-12-24 12:12:12 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
?>
<?php
  self::$db->query("LOCK TABLES mod_adblock WRITE");
  self::$db->query("ALTER TABLE mod_adblock ADD COLUMN title_$flag_id VARCHAR(100) NOT NULL AFTER title_en");
  self::$db->query("UNLOCK TABLES");

  if ($mod_adblock = self::$db->fetch_all("SELECT * FROM mod_adblock")) {
      foreach ($mod_adblock as $row) {
          $data['title_' . $flag_id] = $row->title_en;
          self::$db->update("mod_adblock", $data, "id = " . $row->id);
      }
      unset($data, $row);
  }
?>