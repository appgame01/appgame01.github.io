<?php
  /**
   * Module Index
   *
   * @package CMS Pro
   * @author wojoscripts.com
   * @copyright 2014
   * @version $Id: mod_index.php, v4.00 2014-04-20 10:12:05 gewa Exp $
   */
  
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
?>
<?php include("header.tpl.php");?>
<?php if ($widgettop): ?>
<!-- Top Widgets -->
<div id="topwidget">
  <?php include(THEMEDIR . "/top_widget.tpl.php");?>
</div>
<!-- Top Widgets /-->
<?php endif;?>
<div class="subheader">
  <div class="wojo-grid">
    <div class="wojo-content-full relative">
      <?php if($core->showsearch):?>
      <form id="livesearch" action="<?php echo Url::Page($core->search_page);?>" method="post" name="search-form" class="push-right">
        <!-- Livesearch Start -->
          <div class="wojo inverted icon input">
            <input id="searchfield" name="keywords" placeholder="<?php echo Lang::$word->_SEARCH;?>..." type="text">
            <i class="search link icon"></i> </div>
          <div id="suggestions"></div>
        <!--/ Livesearch End -->
      </form>
      <?php endif;?>
      <?php if($content->modalias and $core->showcrumbs):?>
      <div class="wojo breadcrumb"><a href="<?php echo SITEURL;?>/" class="section"><?php echo Lang::$word->_HOME;?></a>
        <div class="divider"></div>
        <div class="active section"><?php echo $content->getBreadcrumbs();?></div>
      </div>
      <?php endif;?>
      <h1><?php echo $content->moduledata->{'title' . Lang::$lang};?>
        <?php if($content->moduledata->{'info' . Lang::$lang}):?>
        <small><?php echo $content->moduledata->{'info' . Lang::$lang};?></small>
        <?php else:?>
        <small>&nbsp;</small>
        <?php endif;?>
      </h1>
    </div>
  </div>
</div>
<?php switch(true): case $widgetleft and $widgetright :?>
<!-- Left and Right Layout -->
<div id="page">
  <div class="wojo-grid">
    <div class="columns">
      <div class="screen-60 tablet-50 phone-100">
        <?php include(THEMEDIR . "/mod_main.tpl.php");?>
      </div>
      <div class="screen-20 tablet-25 phone-100">
        <?php include(THEMEDIR . "/left_widget.tpl.php");?>
      </div>
      <div class="screen-20 tablet-25 phone-100">
        <?php include(THEMEDIR . "/right_widget.tpl.php");?>
      </div>
    </div>
  </div>
</div>
<!-- Left and Right Layout /-->
<?php break;?>
<?php case $widgetleft :?>
<!-- Left Layout -->
<div id="page">
  <div class="wojo-grid">
    <div class="columns">
      <div class="screen-30 tablet-40 phone-100">
        <?php include(THEMEDIR . "/left_widget.tpl.php");?>
      </div>
      <div class="screen-70 tablet-60 phone-100">
        <?php include(THEMEDIR . "/mod_main.tpl.php");?>
      </div>
    </div>
  </div>
</div>
<!-- Left Layout /-->
<?php break;?>
<?php case $widgetright :?>
<!-- Right Layout -->
<div id="page">
  <div class="wojo-grid">
    <div class="columns">
      <div class="screen-70 tablet-60 phone-100">
        <?php include(THEMEDIR . "/mod_main.tpl.php");?>
      </div>
      <div class="screen-30 tablet-40 phone-100">
        <?php include(THEMEDIR . "/right_widget.tpl.php");?>
      </div>
    </div>
  </div>
</div>
<!-- Right Layout /-->
<?php break;?>
<?php default:?>
<!-- Full Layout -->
<div id="page">
  <div class="wojo-grid">
    <?php include(THEMEDIR . "/mod_main.tpl.php");?>
  </div>
</div>
<!-- Full Layout /-->
<?php break;?>
<?php endswitch;?>
<?php if ($widgetbottom): ?>
<!-- Bottom Widgets -->
<div id="botwidget">
  <div class="wojo-grid">
    <?php include(THEMEDIR . "/bottom_widget.tpl.php");?>
  </div>
</div>
<!-- Bottom Widgets /-->
<?php endif;?>
<?php include("footer.tpl.php");?>